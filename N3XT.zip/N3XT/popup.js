document.addEventListener("DOMContentLoaded", function () {
  const linkButton = document.getElementById("link-button");
  if (linkButton) {
    linkButton.addEventListener("click", function () {
      chrome.runtime.sendMessage({ action: "checkLinks" });
    });
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
      if (request.action === "updateResult") {
        // Update alert instead of div
        alert(request.result); 
      }
    });
  } else {
    console.error("Link button not found");
  }
});