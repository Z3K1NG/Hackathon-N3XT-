chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "checkLinks") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: function() {
          const links = [];
          const elements = document.querySelectorAll("a");
          elements.forEach((element) => {
            const link = element.href;
            if (link) {
              links.push(link);
            }
          });
          return links;
        }
      })
      .then((result) => {
        const links = result[0].result; // Access the first result in the array
        if (!links) {
          console.error('No links found');
          return;
        }
        const apiKey = "AIzaSyAdX9Ayr3F4rsmb16vqlTQsi50Ipl7bwjk"; // Replace with your public API key
        const apiUrl = "https://safebrowsing.googleapis.com/v4/threatMatches:find?key=" + apiKey;
        const apiData = {
          "client": {
            "clientId": "yourcompanyname",
            "clientVersion": "1.5.2"
          },
          "threatInfo": {
            "threatTypes": ["MALWARE", "SOCIAL_ENGINEERING"],
            "platformTypes": ["ANY_PLATFORM"],
            "threatEntryTypes": ["URL"],
            "threatEntries": links.map((link) => ({ url: link }))
          }
        };
        fetch(apiUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(apiData)
        })
        .then((response) => response.json())
        .then((data) => {
          const resultText = data.matches ? "Some links are not safe" : "All links are safe";
          chrome.runtime.sendMessage({ action: "updateResult", result: resultText });
        })
        .catch((error) => console.error(error));
      })
      .catch((error) => console.error(error));
    });
  }
});