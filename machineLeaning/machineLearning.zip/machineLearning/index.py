from sklearn.ensemble import RandomForestClassifier
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# file reading
df = pd.read_csv('hackathon/malicious_phish.csv')

# features
def extract_features(df):
    df['url_length'] = df['url'].apply(len)
    df['num_dots'] = df['url'].str.count(r'\\.')
    df['num_slashes'] = df['url'].str.count(r'/')
    df['num_hyphens'] = df['url'].str.count(r'-')
    return df

df = extract_features(df)

# labels converting into numeric 
label_mapping = {'benign': 0, 'defacement': 1, 'malware': 2, 'phishing': 3}
df['type_encoded'] = df['type'].map(label_mapping)

# divide. features and labels
X = df[['url_length', 'num_dots', 'num_slashes', 'num_hyphens']]
y = df['type_encoded']

# learning and testing data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# learning
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# features extraction from user input
def extract_user_input_features(user_input):
    features = {
        'url_length': len(user_input),
        'num_dots': user_input.count('.'),
        'num_slashes': user_input.count('/'),
        'num_hyphens': user_input.count('-')
    }
    return np.array(list(features.values())).reshape(1, -1)

user_input = str(input("Enter a URL: "))

# labels extraction from user input
user_input_features = pd.DataFrame(
    [extract_user_input_features(user_input)[0]],
    columns=['url_length', 'num_dots', 'num_slashes', 'num_hyphens']
)

# prediction
pred = model.predict(user_input_features)

# results
predicted_label = {v: k for k, v in label_mapping.items()}[pred[0]]
print(f"The prediction is: {predicted_label}")

